from game_calculations import GameCalculations
from src.calculations.ways import Ways
from src.events.events import update_global_mult_event


class GameExecutables(GameCalculations):
    """Events specific to 'ways' wins, plus HONK's persistent Goose Meter."""

    def charge_goose_meter(self):
        """Add every goose's multiplier value on the board to the persistent meter.

        Free-spins only. Each goose (W) carries a 2x-10x value assigned at draw
        time; here those values are summed and added to self.global_multiplier,
        which never resets until the bonus ends. The meter then multiplies every
        win for the rest of the RAMPAGE. An event is emitted so the frontend can
        animate the meter climbing before the win lands.
        """
        added = 0
        for reel in self.board:
            for symbol in reel:
                if symbol.check_attribute("multiplier"):
                    added += symbol.get_attribute("multiplier")
        if added > 0:
            self.global_multiplier += added
            update_global_mult_event(self)

    def evaluate_ways_board(self):
        """Populate win-data, record wins, transmit events.

        Base game uses the 'symbol' strategy (each goose boosts the win it
        completes). The RAMPAGE bonus uses the 'global' strategy so the persistent
        Goose Meter multiplies the whole spin win.
        """
        if self.gametype == self.config.freegame_type:
            self.win_data = Ways.get_ways_data(
                self.config,
                self.board,
                global_multiplier=self.global_multiplier,
                multiplier_strategy="global",
            )
        else:
            self.win_data = Ways.get_ways_data(self.config, self.board)

        if self.win_data["totalWin"] > 0:
            Ways.record_ways_wins(self)
            self.win_manager.update_spinwin(self.win_data["totalWin"])
        Ways.emit_wayswin_events(self)
