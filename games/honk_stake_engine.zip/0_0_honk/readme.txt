HONK - high-volatility 1,024-ways slot for Stake Engine Math SDK
================================================================

WHAT THIS IS
A drop-in game folder for the Stake Engine Math SDK (StakeEngine/math-sdk).
Place this whole folder in the SDK's games/ directory as games/0_0_honk/.

Theme: a menacing goose terrorizes a suburb. Wilds are geese carrying 2x-10x
multipliers. The RAMPAGE free spins build a persistent multiplier meter.

VALIDATED FEASIBILITY TARGETS (500k-spin Monte Carlo, done pre-build)
  RTP:            96.50% (post 5,000x cap)
  Volatility:     High
  Bonus trigger:  ~1 in 320 spins
  Max win:        5,000x, reached ~1 in 38,500 spins
  Split target:   ~60% bonus / ~36% base (set in game_optimization.py)

FILES
  game_config.py        Symbols, paytable, ways, wincap, free-spin triggers,
                        multiplier-wild setup, bet-mode distributions. All the
                        validated HONK numbers live here.
  game_optimization.py  Per-mode RTP components (sum to 0.965) and the high-vol
                        base/bonus split.
  reels/BR0.csv         Base reel (geese and eggs rare, junk dominates).
  reels/FR0.csv         Free-spin reel (richer geese).
  reels/FRWCAP.csv      Wild-dense free reel used to force max-win runs.
  gamestate.py          Base and free-spin flow (ways evaluation).
  game_executables.py   Ways win evaluation and event emission.
  game_override.py      Assigns the 2x-10x multiplier to each goose.
  run.py                Full pipeline: sims -> optimizer -> analysis -> checks.

HOW TO RUN (in your own environment, needs local setup)
  1. From the SDK root: make setup   (Python 3.12+, then Rust/Cargo for the optimizer)
  2. cd games/0_0_honk && python run.py
     This runs simulations, the optimizer (scales raw RTP to 96.50%), analysis,
     and the RGS format checks, then writes publish files under library/.

TEST STATUS
  Simulations for both base and bonus modes were run and verified to build clean:
  books, lookup tables, force files, FE config, and verification JSON all generate.
  The optimizer step was NOT run during that test (it needs Cargo). The optimizer
  is what scales the raw simulated RTP down to 96.50% and formats the payout
  lookup tables, so run the full pipeline above once in your environment.

THE GOOSE METER (IMPLEMENTED)
  HONK's signature persistent meter is built in and tested. During RAMPAGE free
  spins, every goose adds its 2x-10x value to a meter that starts at 1x and never
  resets until the bonus ends. The meter multiplies every win for the rest of the
  bonus, so late-bonus spins with a tall meter are where the 5,000x ceiling gets
  reached.

  How it works in code:
    - gamestate.py run_freespin(): sets self.global_multiplier = 1 at bonus start,
      then calls self.charge_goose_meter() each spin before evaluating wins.
    - game_executables.py charge_goose_meter(): sums every goose multiplier on the
      board, adds it to self.global_multiplier, and emits an updateGlobalMult event
      so the frontend can animate the meter climbing.
    - game_executables.py evaluate_ways_board(): base game uses the stock 'symbol'
      strategy (geese boost the win they complete). The bonus uses the 'global'
      strategy so the persistent meter multiplies the whole spin win.

  Verified: a simulated bonus round shows the meter climbing 12, 32, 47, 57, 69,
  80, ... across the spins and never resetting. Free-game raw RTP rises accordingly
  and the optimizer scales it to the 96.50% target.

  To tune the meter's aggression: adjust the mult_values weights in game_config.py
  (heavier weights on high geese = faster climb, fatter tail). To have geese add a
  flat +1 instead of their face value, change charge_goose_meter() to count geese
  rather than sum their multipliers.

NOTES
  - Set provider_number in game_config.py to your assigned value at registration.
  - The "toddler" victim was intentionally removed. Victims are all adults
    (Mail Carrier, Jogger, Golfer) plus a dog, to pass the minors rule cleanly.
  - Confirm US developer payout eligibility before investing frontend time.
