import os
from src.config.config import Config
from src.config.distributions import Distribution
from src.config.betmode import BetMode


class GameConfig(Config):
    """HONK - high-volatility 1,024-ways slot. A menacing goose terrorizes a suburb.

    Validated feasibility targets (500k-spin Monte Carlo):
      RTP 96.50%, high volatility, bonus trigger ~1 in 320, max win 5,000x.
    The optimizer finalizes RTP and the base/bonus split via reel_weights below.
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        super().__init__()
        self.game_id = "0_0_honk"
        self.provider_number = 0  # set this to your assigned provider number at registration
        self.working_name = "HONK"
        self.wincap = 5000
        self.win_type = "ways"
        self.rtp = 0.965
        self.construct_paths()

        # Game dimensions: 5x4 = 1,024 ways
        self.num_reels = 5
        self.num_rows = [4] * self.num_reels

        # Paytable (count, symbol): pay per way. Validated HONK values.
        # Highs are the victims (H1 Mail Carrier, H2 Jogger, H3 Golfer, H4 Dog).
        # Lows are suburban junk (L1 Trash Can, L2 Flamingo, L3 Gnome, L4 Sprinkler).
        self.paytable = {
            (5, "H1"): 7.0, (4, "H1"): 2.0, (3, "H1"): 0.5,
            (5, "H2"): 5.0, (4, "H2"): 1.5, (3, "H2"): 0.4,
            (5, "H3"): 3.5, (4, "H3"): 1.0, (3, "H3"): 0.3,
            (5, "H4"): 3.0, (4, "H4"): 0.8, (3, "H4"): 0.25,
            (5, "L1"): 0.5, (4, "L1"): 0.15, (3, "L1"): 0.04,
            (5, "L2"): 0.4, (4, "L2"): 0.12, (3, "L2"): 0.03,
            (5, "L3"): 0.3, (4, "L3"): 0.10,
            (5, "L4"): 0.25, (4, "L4"): 0.08,
        }

        self.include_padding = True
        # The Goose is both the wild and the multiplier-carrier (2x-10x).
        self.special_symbols = {"wild": ["W"], "scatter": ["S"], "multiplier": ["W"]}

        # RAMPAGE free spins: 3/4/5 eggs -> 10/14/20 spins. 3+ eggs retrigger +5.
        self.freespin_triggers = {
            self.basegame_type: {3: 10, 4: 14, 5: 20},
            self.freegame_type: {3: 5, 4: 5, 5: 5},
        }
        self.anticipation_triggers = {self.basegame_type: 2, self.freegame_type: 1}

        # Reels: BR0 base, FR0 free, FRWCAP wild-dense free reel for forcing max-win runs.
        reels = {"BR0": "BR0.csv", "FR0": "FR0.csv", "FRWCAP": "FRWCAP.csv"}
        self.reels = {}
        for r, f in reels.items():
            self.reels[r] = self.read_reels_csv(os.path.join(self.reels_path, f))

        mode_maxwins = {"base": 5000, "bonus": 5000}

        # Goose multiplier spread (value: weight), weighted toward smaller geese.
        base_mult = {1: 1}
        goose_mult = {2: 35, 3: 25, 4: 15, 5: 9, 6: 6, 7: 4, 8: 3, 9: 2, 10: 1}

        self.bet_modes = [
            BetMode(
                name="base",
                cost=1.0,
                rtp=self.rtp,
                max_win=mode_maxwins["base"],
                auto_close_disabled=False,
                is_feature=True,
                is_buybonus=False,
                distributions=[
                    Distribution(
                        criteria="wincap",
                        quota=0.001,
                        win_criteria=mode_maxwins["base"],
                        conditions={
                            "reel_weights": {
                                self.basegame_type: {"BR0": 1},
                                self.freegame_type: {"FR0": 1, "FRWCAP": 5},
                            },
                            "force_wincap": True,
                            "force_freegame": True,
                            "scatter_triggers": {3: 100, 4: 20, 5: 5},
                            "mult_values": goose_mult,
                        },
                    ),
                    Distribution(
                        criteria="freegame",
                        quota=0.1,
                        conditions={
                            "reel_weights": {
                                self.basegame_type: {"BR0": 1},
                                self.freegame_type: {"FR0": 1},
                            },
                            "force_wincap": False,
                            "force_freegame": True,
                            "scatter_triggers": {3: 100, 4: 20, 5: 5},
                            "mult_values": goose_mult,
                        },
                    ),
                    Distribution(
                        criteria="0",
                        quota=0.4,
                        win_criteria=0.0,
                        conditions={
                            "reel_weights": {self.basegame_type: {"BR0": 1}},
                            "force_wincap": False,
                            "force_freegame": False,
                            "mult_values": base_mult,
                        },
                    ),
                    Distribution(
                        criteria="basegame",
                        quota=0.5,
                        conditions={
                            "reel_weights": {self.basegame_type: {"BR0": 1}},
                            "force_wincap": False,
                            "force_freegame": False,
                            "mult_values": base_mult,
                        },
                    ),
                ],
            ),
            BetMode(
                name="bonus",
                cost=100.0,
                rtp=self.rtp,
                max_win=mode_maxwins["bonus"],
                auto_close_disabled=False,
                is_feature=False,
                is_buybonus=True,
                distributions=[
                    Distribution(
                        criteria="freegame",
                        quota=1,
                        conditions={
                            "reel_weights": {
                                self.basegame_type: {"BR0": 1},
                                self.freegame_type: {"FR0": 1, "FRWCAP": 5},
                            },
                            "force_wincap": False,
                            "force_freegame": True,
                            "scatter_triggers": {3: 100, 4: 20, 5: 5},
                            "mult_values": goose_mult,
                        },
                    ),
                ],
            ),
        ]
